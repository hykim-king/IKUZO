package com.pcwk.ehr.answer;

import java.util.Iterator;
import java.util.List;

import com.pcwk.ehr.cmn.PLog;

public class AnswerDaoMain implements PLog{

	AnswerDao dao;
	AnswerDTO answer01;
	
	public AnswerDaoMain() {
		dao = new AnswerDao();
		
		answer01 = new AnswerDTO(70, "내용_70", 70, "admin_70", "사용안함", "admin_70", "사용안함");
		// answer01 = new BoardDTO(10, "내용_10", 0, "admin_10", "사용안함", "admin_10", "사용안함");
	}
	
	public void doSave(){
		log.debug("doSave()");
		int flag = dao.doSave(answer01);
		if (1==flag) {
			log.debug("성공 : {}", flag);
		}else {
			log.debug("실패 : {}", flag);			
		}
	} // doSave끝 
	
	public void doDelete(){
		log.debug("doDelete()");
		int flag = dao.doDelete(answer01);
		if (1==flag) {
			log.debug("삭제 성공 : {}", flag);
		}else {
			log.debug("삭제 실패 : {}", flag);			
		}
	} // doDelete끝 	
	
	// 내가 만든 조회수 메서드 시작
	public void readCntPlus(){
		log.debug("readCntPlus()");
		int flag = dao.readCntPlus(answer01);
		if (1==flag) {
			log.debug("조회수 증가 : {}", flag);
		}else {
			log.debug("조회수 실패 : {}", flag);			
		}
	} // readCntPlus끝 		
	
	// 교수님이 만든 조회수 메서드 시작
	public void doUpdateReadcnt(){
		log.debug("doUpdateReadcnt()");
		int flag = dao.doUpdateReadcnt(answer01);
		if (1==flag) {
			log.debug("조회수 증가(교수님) : {}", flag);
		}else {
			log.debug("조회수 실패(교수님) : {}", flag);			
		}
	} // doUpdateReadcnt끝 
	
	public void doSelectOne(){
		log.debug("doSelectOne()");
		AnswerDTO outVO = dao.doSelectOne(answer01);
		if (null != outVO) {
			log.debug("검색 성공 : {}", outVO);
		}else {
			log.debug("검색 실패 : {}", outVO);			
		}
	} // doSelectOne끝 	
	
	public void doUpdate(){
		log.debug("doUpdate()");
		// content,modid 뒤에 _u추가
			String updateStr = "_U";		
			this.answer01.setContents(answer01.getContents()+updateStr);
			answer01.setModId(answer01.getModId()+updateStr);
		// content,modid 뒤에 _u추가 끝
		int flag = dao.doUpdate(answer01);
		if (1==flag) {
			log.debug("업데이트 성공 : {}", flag);
		}else {
			log.debug("업데이트 실패 : {}", flag);			
		}
	} // doUpdate끝 	
	
	public void doRetrieve() {
		log.debug("doRetrieve()");
		SearchDTO searchVO = new SearchDTO();
		searchVO.setPageNo(1);
		searchVO.setPageSize(10);
		
		// 검색구분
		searchVO.setSearchDiv("40"); 	// 10 : 내용 | 20 : 등록자 | 30 : 제목, 내용 | 40 : 게시판 시퀀스
		searchVO.setSearchWord("900");	// 검색어
		
		List<AnswerDTO> list = dao.doRetrieve(searchVO);
		
		int i =0;
		
		for (AnswerDTO vo :list) {
			log.debug("i: {}, vo: {}", ++i, vo);
		}
	} // doRetrieve 끝

	public void addAndGet() {
		// 1. 삭제 : 성공 실패 여부를 따지지 않는다
		// 2. 등록 : 
		// 3. 조회 : 
		log.debug("doRetrieve()");
		
		// 1. 
		dao.doDelete(answer01);
		
		// 2. 
		int flag = dao.doSave(answer01);
		if (1 == flag) {
			log.debug("등록 성공 : {}", flag);
		}else {
			log.debug("등록 실패 : {}", flag);
			return;
		}
		
		// 3. 
		AnswerDTO outVO = dao.doSelectOne(answer01);		

		boolean isSame = isSameData(outVO, answer01);
		
		if (false == isSame) {
			log.debug("─────────────────");
			log.debug("───────나가───────");
			log.debug("─────────────────");			
		}else {		
			log.debug("─────────────────");
			log.debug("───────성공───────");
			log.debug("─────────────────");
		}
		//m.doSelectOne();
		//m.doSave();
		//m.doDelete();	
	}
	
	public boolean isSameData(AnswerDTO outVO, AnswerDTO answer01) {
		// answer01, outVO 비교
				if (outVO.getSeq() != answer01.getSeq()) {
					log.debug("실패 seq : {},{}", outVO.getSeq(),answer01.getSeq());
					return false;
				}

				// 내용
				if (!outVO.getContents().equals(answer01.getContents())) {
					log.debug("실패 contents : {},{}", outVO.getContents(),answer01.getContents());
					return false;
				}
				
				// 등록자 ID
				if (!outVO.getRegId().equals(answer01.getRegId())) {
					log.debug("실패 regId : {},{}", outVO.getRegId(),answer01.getRegId());
					return false;
				}
				return true;
	}
	
	public static void main(String[] args) {
		AnswerDaoMain m = new AnswerDaoMain();
		m.doRetrieve();
		//m.readCntPlus();
		//m.doUpdateReadcnt();
		//m.doUpdate();
		//m.addAndGet();
	} // main

} // class