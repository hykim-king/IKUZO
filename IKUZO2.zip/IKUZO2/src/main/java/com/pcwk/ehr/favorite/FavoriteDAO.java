package com.pcwk.ehr.favorite;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.pcwk.ehr.board.DBUtil;
import com.pcwk.ehr.board.SearchDTO;
import com.pcwk.ehr.cmn.ConnectionMarker;
import com.pcwk.ehr.cmn.DTO;
import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.cmn.WorkDiv;

public class FavoriteDAO implements WorkDiv<FavoriteDTO>, PLog {

    private ConnectionMarker connectionMaker;

    public FavoriteDAO() {
        connectionMaker = new ConnectionMarker();
        log.debug("FavoriteDAO() connectionMaker : {}", connectionMaker);
    }

  /*  public FavoriteDTO doSelectOne(FavoriteDTO param) {
        FavoriteDTO outVO = null;
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        StringBuilder sb = new StringBuilder(1000);

      

        try {
            conn = connectionMaker.getConnection();
            pstmt = conn.prepareStatement(sb.toString());
            pstmt.setInt(1, param.getFavSeq()); // 파라미터 설정
            rs = pstmt.executeQuery();

            if (rs.next()) {
                outVO = new FavoriteDTO();

                outVO.setFavSeq(rs.getInt("FAV_SEQ"));
                //outVO.setUserId(rs.getString("USER_ID"));
                //outVO.setBookCode(rs.getInt("BOOK_CODE"));
                outVO.setBookName(rs.getString("BOOK_NAME")); 
                outVO.setBookGenre(rs.getString("BOOK_GENRE")); 
                outVO.setRegDt(rs.getString("REG_DT"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
        }
        return outVO;
    } */

    @Override
    public List<FavoriteDTO> doRetrieve(DTO search) {
        SearchDTO searchVO = (SearchDTO) search;
        log.debug("doRetrieve");
        List<FavoriteDTO> list = new ArrayList<>();
        StringBuilder sb = new StringBuilder(1000);
        StringBuilder sbWhere = new StringBuilder(1000);
        
        if (null != searchVO.getSearchDiv() && searchVO.getSearchDiv().equals("10")) {
			sbWhere.append("WHERE FAV_SEQ LIKE ?||'%' \n");
		}else if(null != searchVO.getSearchDiv() && searchVO.getSearchDiv().equals("20")) {
			sbWhere.append("WHERE BOOK_NAME LIKE ?||'%' \n");			
		}else if(null != searchVO.getSearchDiv() && searchVO.getSearchDiv().equals("30")) {
			sbWhere.append("WHERE BOOK_GENRE = ? \n");			
		}else (null != searchVO.getSearchDiv() && searchVO.getSearchDiv().equals("40")) {
			sbWhere.append("WHERE AUTHOR LIKE ?||'%' \n");			
		}
        
        
        Connection conn = connectionMaker.getConnection();
		PreparedStatement pstmt = null; // SQL+PARAM
		ResultSet	rs			= null; // SQL문의 결과
        
        
        
        sb.append("SELECT                             	\n");        
        sb.append("    f.FAV_SEQ,     					\n");                                                   
        sb.append("    b.BOOK_NAME,                     \n");
        sb.append("    b.BOOK_GENRE,                    \n");
        sb.append("    b.AUTHOR                         \n");                   
        sb.append("FROM Favorite f                  	\n");                 
        sb.append("JOIN book b ON f.BOOK_CODE = b.BOOK_CODE 	\n");                                  
        sb.append("WHERE 1=1                        	\n");                                
        sb.append("ORDER BY f.FAV_SEQ                	\n");

        log.debug("1.sql: {} \n", sb.toString());
		log.debug("2.conn: {} \n", conn);
		log.debug("3.param: {}", search);
        
        try {
            conn = connectionMaker.getConnection();
            pstmt = conn.prepareStatement(sb.toString());

            int i = 1;
            if (searchVO.getSearchWord() != null && !searchVO.getSearchWord().isEmpty()) {
                pstmt.setString(i++, "%" + searchVO.getSearchWord() + "%");
            }
            	
            
            //select 실행
            rs = pstmt.executeQuery();
            log.debug("5.rs:\n" + rs);
            
            while (rs.next()) {
                FavoriteDTO outVO = new FavoriteDTO();

                outVO.setFavSeq(rs.getInt("FAV_SEQ"));
                outVO.setBookName(rs.getString("BOOK_NAME"));
                outVO.setBookGenre(rs.getString("BOOK_GENRE"));
                outVO.setAuthor(rs.getString("AUTHOR"));
                //outVO.setRegDt(rs.getString("REG_DT"));

                list.add(outVO);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt, rs);
            log.debug("6. finally : conn : {} pstmt : {} rs : {}", conn, pstmt, rs);
        }
        return list;
    }

    @Override
    public int doSave(FavoriteDTO param) {
        int flag = 0;
        Connection conn = null;
        PreparedStatement pstmt = null;
        StringBuilder sb = new StringBuilder(1000);

        sb.append("INSERT INTO favorite (FAV_SEQ, USER_ID, BOOK_CODE, REG_DT)  \n");
        sb.append("VALUES (?, ?, ?, SYSDATE) \n");

        try {
            conn = connectionMaker.getConnection();
            pstmt = conn.prepareStatement(sb.toString());

            pstmt.setInt(1, param.getFavSeq());
            pstmt.setString(2, param.getUserId());
            pstmt.setInt(3, param.getBookCode());

            flag = pstmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.close(conn, pstmt);
        }
        return flag;
    }

    @Override
    public int doUpdate(FavoriteDTO param) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int doDelete(FavoriteDTO param) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int doSaveFile() {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int doReadFile() {
        // TODO Auto-generated method stub
        return 0;
    }

}
