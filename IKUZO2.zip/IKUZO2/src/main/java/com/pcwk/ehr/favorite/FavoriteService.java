package com.pcwk.ehr.favorite;

import java.util.List;

import com.pcwk.ehr.board.BoardDTO;
import com.pcwk.ehr.cmn.DTO;
import com.pcwk.ehr.cmn.PLog;

public class FavoriteService implements PLog {

	private FavoriteDAO dao;
	public	FavoriteService() {
		dao = new FavoriteDAO();
	}
	
	// 목록 조회
	public List<FavoriteDTO> doRetrieve(DTO search){
		return dao.doRetrieve(search);
	}
	
	// 저장
	public int doSave(FavoriteDTO param) {
		return dao.doSave(param);
	}
	
	// 수정
	public int doUpdate(FavoriteDTO param) {
		return dao.doUpdate(param);
	}
	
	// 삭제
	public int doDelete(FavoriteDTO param) {
		return dao.doDelete(param);
	}	
	
	
	public FavoriteDTO selectOneReadCnt(FavoriteDTO param) {
		return dao.doSelectOne(param);
	}
} // class