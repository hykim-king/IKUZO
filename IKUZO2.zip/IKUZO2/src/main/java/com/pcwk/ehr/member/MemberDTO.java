package com.pcwk.ehr.member;

import com.pcwk.ehr.cmn.DTO;

public class MemberDTO extends DTO {
	private String userId; 		// 회원id
	private String name;		// 이름
	private String password;	// 비번
	private String email;		// 이메일
	private String reg_id;		// 등록자
	private String reg_dt;		// 등록일

	public MemberDTO() {}

	public MemberDTO(String userId, String name, String password, String email, String reg_id, String reg_dt) {
		super();
		this.userId = userId;
		this.name = name;
		this.password = password;
		this.email = email;
		this.reg_id = reg_id;
		this.reg_dt = reg_dt;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getReg_id() {
		return reg_id;
	}

	public void setReg_id(String reg_id) {
		this.reg_id = reg_id;
	}

	public String getReg_dt() {
		return reg_dt;
	}

	public void setReg_dt(String reg_dt) {
		this.reg_dt = reg_dt;
	}

	@Override
	public String toString() {
		return "MemberDTO [userId=" + userId + ", name=" + name + ", password=" + password + ", email=" + email
				+ ", reg_id=" + reg_id + ", reg_dt=" + reg_dt + ", toString()=" + super.toString() + "]";
	}
	
}

