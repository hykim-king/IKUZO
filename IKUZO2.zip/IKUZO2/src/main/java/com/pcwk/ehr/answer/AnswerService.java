package com.pcwk.ehr.answer;

import java.util.List;

import com.pcwk.ehr.cmn.DTO;
import com.pcwk.ehr.cmn.PLog;

public class AnswerService implements PLog {

	private AnswerDao dao;
	public	AnswerService() {
		dao = new AnswerDao();
	}
	
	// 목록 조회
	public List<AnswerDTO> doRetrieve(DTO search){
		return dao.doRetrieve(search);
	}
	
	// 저장
	public int doSave(AnswerDTO param) {
		return dao.doSave(param);
	}
	
	// 수정
	public int doUpdate(AnswerDTO param) {
		return dao.doUpdate(param);
	}
	
	// 삭제
	public int doDelete(AnswerDTO param) {
		return dao.doDelete(param);
	}	
	
	// doSelectOne + doUpdateReadcnt
	public AnswerDTO selectOneReadCnt(AnswerDTO param) {
		AnswerDTO outVO = null;
		
		// doSelectOne
		outVO = dao.doSelectOne(param);
		
		// 조회 성공시 updateReadCnt 호출
		if(null != outVO) {
			int flag = dao.doUpdateReadcnt(param);
			log.debug("flag : {}", flag);
			
			outVO.setFlag(flag);
		}
		
		return outVO;
	}
} // class