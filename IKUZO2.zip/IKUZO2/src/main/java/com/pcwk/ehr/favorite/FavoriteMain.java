package com.pcwk.ehr.favorite;

import java.util.List;
import com.pcwk.ehr.board.SearchDTO;
import com.pcwk.ehr.cmn.PLog;

public class FavoriteMain implements PLog {
    FavoriteDAO dao;
    FavoriteDTO dto;
    

    public FavoriteMain() {
        dao = new FavoriteDAO();
    }

    
    
	public void doSave(){
		log.debug("doSave()");
		int flag = dao.doSave(dto);
		if (1==flag) {
			log.debug("성공 : {}", flag);
		}else {
			log.debug("실패 : {}", flag);			
		}
	} // doSaveEnd 
	
	
	
	
	
	public void doSelectOne() {
        FavoriteDAO dao = new FavoriteDAO();

        FavoriteDTO param = new FavoriteDTO();
        param.setFavSeq(1); // 예시로 favSeq 값을 설정

        FavoriteDTO outVO = dao.doSelectOne(param);

        if (outVO != null) {
            System.out.println("Selected FavoriteDTO: " + outVO);
        } else {
            System.out.println("FavoriteDTO not found for favSeq: " + param.getFavSeq());
        }
    }
	
	
	
    public void doRetrieve() {
        log.debug("doRetrieve()");
        
        // 검색 조건 설정
        SearchDTO searchVO = new SearchDTO();
        searchVO.setPageNo(1);
        searchVO.setPageSize(10);
    	searchVO.setSearchDiv("50");
		searchVO.setSearchWord("80");
        
        
        // 즐겨찾기 목록 조회
        List<FavoriteDTO> list = dao.doRetrieve(searchVO);
        
        // 조회 결과 출력
        int i = 0;
        for (FavoriteDTO vo : list) {
            log.debug("i: {}, vo: {}", ++i, vo);
            // 필요한 로직 추가
        }
    }

    public static void main(String[] args) {
        FavoriteMain m = new FavoriteMain();
        m.doRetrieve();
        //m.doSave();
        //m.doSelectOne();
    }
}
