package com.pcwk.ehr.board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUtil {
	  //close
    public static void close(Connection conn, PreparedStatement pstmt,ResultSet rs) {
        if(null !=rs) {
            try {
                rs.close();
            } catch (SQLException e) {
            }
        }
        
        if(null !=pstmt) {
            try {
                pstmt.close();
            } catch (SQLException e) {
            }
        }       
        
        if(null !=conn) {
            try {
                conn.close();
            } catch (SQLException e) {
            }
        }           
        
    }   
    //close
    public static void close(Connection conn, PreparedStatement pstmt) {
        if(null !=pstmt) {
            try {
                pstmt.close();
            } catch (SQLException e) {
            }
        }       
        
        if(null !=conn) {
            try {
                conn.close();
            } catch (SQLException e) {
            }
        }           
        
    }
	public static String formatQuery(String string, int seq, String contents, int boardSeq, String regId,
			String regId2) {
		// TODO Auto-generated method stub
		return null;
	}

}