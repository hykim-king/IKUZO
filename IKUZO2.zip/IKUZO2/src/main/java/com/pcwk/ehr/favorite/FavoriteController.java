package com.pcwk.ehr.favorite;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pcwk.ehr.board.SearchDTO;
import com.pcwk.ehr.cmn.ControllerV;
import com.pcwk.ehr.cmn.JView;
import com.pcwk.ehr.cmn.PLog;
import com.pcwk.ehr.cmn.StringUtil;

public class FavoriteController extends HttpServlet implements ControllerV, PLog {
    private static final long serialVersionUID = 1L;

    FavoriteService service;

    public FavoriteController() {
        log.debug("-----------------");
        log.debug("FavoriteController()");
        log.debug("-----------------");

        service = new FavoriteService();
    }

/*    private JView doSave(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        log.debug("-----------------");
        log.debug("doSave()");
        log.debug("-----------------");

        FavoriteDTO inVO = new FavoriteDTO();

        String favSeqStr = StringUtil.nvl(request.getParameter("favSeq"), "0");
        String userId = StringUtil.nvl(request.getParameter("userId"), "");
        String bookCodeStr = StringUtil.nvl(request.getParameter("bookCode"), "0");
        String regDt = StringUtil.nvl(request.getParameter("regDt"), "");

        int favSeq = 0;
        int bookCode = 0;

        try {
            favSeq = Integer.parseInt(favSeqStr);
            bookCode = Integer.parseInt(bookCodeStr);
        } catch (NumberFormatException e) {
        	response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        	return new JView("/error.jsp");
        }

        log.debug("setFavSeq : {}", favSeq);
        log.debug("setUserId : {}", userId);
        log.debug("setBookCode : {}", bookCode);
        log.debug("setRegDt : {}", regDt);

        inVO.setFavSeq(favSeq);
        inVO.setUserId(userId);
        inVO.setBookCode(bookCode);
        inVO.setRegDt(regDt);

        int flag = this.service.doSave(inVO);
        log.debug("flag : {}", flag);

        if (1 == flag) {
            return new JView("/board/board.do?work_div=doRetrieve");
        }

        return null;
    } */

    public JView doSelectOne(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        log.debug("-----------------");
        log.debug("doSelectOne()");
        log.debug("-----------------");
        FavoriteDTO inVO = new FavoriteDTO();
        String favSeq = StringUtil.nvl(request.getParameter("favSeq"), "0");

        inVO.setFavSeq(Integer.parseInt(favSeq));
        log.debug("inVO" + inVO);

        FavoriteDTO outVO = this.service.selectOneReadCnt(inVO);
        log.debug("outVO" + outVO);

        // UI 데이터 전달
        request.setAttribute("outVO", outVO);

        return new JView("/board/board_mng.jsp");
    }
    

    public JView doRetrieve(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        log.debug("-----------------");
        log.debug("doRetrieve()");
        log.debug("-----------------");

        // JSP viewName 저장(경로)
        JView viewName = null;

        SearchDTO inVO = new SearchDTO();

        String pageNo = StringUtil.nvl(request.getParameter("page_no"), "1");
        String pageSize = StringUtil.nvl(request.getParameter("page_size"), "10");

        String searchWord = StringUtil.nvl(request.getParameter("search_word"), "");
        String searchDiv = StringUtil.nvl(request.getParameter("search_div"), "");

        log.debug("pageNo : {}", pageNo);
        log.debug("pageSize : {}", pageSize);
        log.debug("searchWord : {}", searchWord);
        log.debug("searchDiv : {}", searchDiv);

        inVO.setPageNo(Integer.parseInt(pageNo));
        inVO.setPageSize(Integer.parseInt(pageSize));
        inVO.setSearchDiv(searchDiv);
        inVO.setSearchWord(searchWord);

        log.debug("inVO : {}", inVO);

        // service call
        List<FavoriteDTO> list = service.doRetrieve(inVO);

        // reutrn 데이터 확인
        int i = 0;
        for (FavoriteDTO vo : list) {
            log.debug("i : {}, vo : {}", ++i, vo);
        }

        // UI 데이터 전달
        request.setAttribute("list", list);

        // 검색조건 UI로 전달
        request.setAttribute("vo", inVO);

        return new JView("/board/board_list.jsp");
    }

    @Override
    public JView doWork(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        // TODO Auto-generated method stub
        return null;
    }
}
