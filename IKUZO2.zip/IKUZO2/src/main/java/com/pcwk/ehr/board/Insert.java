package com.pcwk.ehr.board;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Insert {
	
	public static void main(String[] args) {
		
	
	  Connection conn = null;
      PreparedStatement pstmt = null;
      Scanner input = new Scanner(System.in);

      try {
          Class.forName("oracle.jdbc.driver.OracleDriver");
          conn = DriverManager.getConnection("jdbc:oracle:thin:@192.168.0.30:1521:xe", "scott", "pcwk");
          
          if (conn == null) {
              System.out.println("DB접속실패");
          } else {
              System.out.println("DB접속 성공");

              System.out.println("번호를 입력해 등록하세요.");
              
              int seq = input.nextInt();
              input.nextLine();
              String title = input.nextLine();
              String contents = input.nextLine();
               
              
              String sql = String.format("INSERT INTO board (seq,title,contents)values (?,?,?)");
              //
               pstmt = conn.prepareStatement(sql);
              
	            pstmt.setInt(1, seq);
	  			pstmt.setString(2, title);
	  			pstmt.setString(3, contents); 
	  			
               int result = pstmt.executeUpdate();

              System.out.println(result + "번이 등록되었어요.");
          } 
      } catch (ClassNotFoundException e) {
          e.printStackTrace();
      } catch (SQLException e) {
          e.printStackTrace();
      } catch(InputMismatchException e) {
    	  e.printStackTrace();
      } finally {
          try {
              if (pstmt != null)
                  pstmt.close();
              if (conn != null)
                  conn.close();
          } catch (SQLException e) {
              e.printStackTrace();
          }
          input.close();
      }
  }
}






