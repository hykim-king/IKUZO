package com.pcwk.ehr.answer;

import com.pcwk.ehr.cmn.PLog;

public class AnswerServiceMain implements PLog{
	
	AnswerService service;
	AnswerDTO answer01;
	
	public AnswerServiceMain() {
		service = new AnswerService();
		
		answer01 = new AnswerDTO(70, "내용_70", 0, "admin_70", "사용안함", "admin_70", "사용안함");
	}
	public void selectOneReadCnt() {
		log.debug("selectOneReadCnt()");
	
		AnswerDTO dto = service.selectOneReadCnt(answer01);
		if(null !=dto && dto.getFlag()==1) {
			log.debug("조회 및 readCount 처리 성공");
		}else {
			log.debug("조회 및 readCount 처리 실패");			
		}
	}
	
	public static void main(String[] args) {
		AnswerServiceMain mService = new AnswerServiceMain();
		mService.selectOneReadCnt();
	} // main

} // class
